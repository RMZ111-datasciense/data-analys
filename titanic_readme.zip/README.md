# 🚢 Titanic Survivors Prediction — Machine Learning Project

This project predicts whether a passenger survived the Titanic disaster using machine learning techniques.  
The dataset is taken from the famous [Kaggle Titanic Competition](https://www.kaggle.com/c/titanic).

---

## 📊 Project Overview

In this project, we:
1. Loaded and explored the Titanic dataset  
2. Handled missing data and performed data preprocessing  
3. Encoded categorical features (Sex, Embarked, etc.)  
4. Built a Machine Learning model to predict survival  
5. Optimized the model using GridSearchCV  

---

## 🧠 Model Used

- **Algorithm:** Random Forest Classifier  
- **Best Parameters:**  
  - `max_depth = 5`  
  - `min_samples_split = 2`  
  - `n_estimators = 100`  
- **Accuracy:** **81.01%**

---

## 🧰 Technologies Used

- Python 🐍  
- Pandas, NumPy  
- Scikit-learn  
- Matplotlib, Seaborn  
- Jupyter Notebook  

---

## 📁 Files in This Repository

| File | Description |
|------|--------------|
| `titanic.ipynb` | Jupyter notebook with full analysis and model training |
| `titanic.csv` | Dataset used for the project |
| `README.md` | Project description (this file) |

---

## 📈 Result

✅ The optimized Random Forest model achieved **81.01% accuracy**  
✅ Successfully cleaned, visualized, and modeled Titanic survival data  
✅ Prepared for portfolio and Kaggle sharing

---

## 💡 Future Improvements

- Try other ML models like XGBoost or LightGBM  
- Perform feature engineering (Title extraction from Name, Family size, etc.)  
- Deploy the model using Streamlit or Flask  

---

## ✨ Author
**Ramziddin Toxirov**  
*Data Science & Machine Learning Enthusiast*  
📧 Contact: [Your GitHub or email here]
